"use client"

import { useState, useEffect } from "react"
import {
  LogOut,
  Menu,
  X,
  HomeIcon,
  Pill,
  Users,
  Building2,
  TrendingUp,
  ShoppingCart,
  FileText,
  Check,
  ArrowRight,
  ChevronDown,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface Drug {
  id: string
  name: string
  category: string
  quantity: number
  price: number
  expiryDate: string
  batchNumber: string
}

interface Customer {
  id: string
  name: string
  phone: string
  email: string
  address: string
  totalDue: number
  totalReceived: number
  totalRevenue: number
}

interface CustomerTransaction {
  id: string
  customerId: string
  type: "sale" | "payment"
  amount: number
  date: string
  description: string
  paymentStatus: string
}

interface Supplier {
  id: string
  name: string
  phone: string
  email: string
  city: string // Added city field
  totalPending: number
  totalPaid: number
}

interface SupplierTransaction {
  id: string
  supplierId: string
  type: "purchase" | "payment"
  amount: number
  date: string
  description: string
  paymentStatus: string
}

interface SupplierPayment {
  id: string
  supplierId: string
  amount: number
  date: string
  paymentMethod: string
  referenceNo: string
}

interface Purchase {
  id: string
  supplierId: string
  drugId: string
  quantity: number
  price: number
  date: string
  paymentStatus: string
}

interface Sale {
  id: string
  customerId: string
  drugId: string
  quantity: number
  amount: number
  date: string
  paymentStatus: string
}

export default function MedifluxApp() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [currentPage, setCurrentPage] = useState("home")
  const [currentSubPage, setCurrentSubPage] = useState("") // Added for sub-pages
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [isMobile, setIsMobile] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [expandedMenu, setExpandedMenu] = useState<string | null>(null) // For collapsible sidebar menus

  const [drugs, setDrugs] = useState<Drug[]>([])
  const [customers, setCustomers] = useState<Customer[]>([])
  const [customerTransactions, setCustomerTransactions] = useState<CustomerTransaction[]>([]) // Added for customer ledger
  const [suppliers, setSuppliers] = useState<Supplier[]>([])
  const [supplierTransactions, setSupplierTransactions] = useState<SupplierTransaction[]>([]) // Added for supplier ledger
  const [supplierPayments, setSupplierPayments] = useState<SupplierPayment[]>([]) // Added for supplier payments
  const [purchases, setPurchases] = useState<Purchase[]>([])
  const [sales, setSales] = useState<Sale[]>([])

  useEffect(() => {
    const savedEmail = localStorage.getItem("mediflux_email")
    if (savedEmail) {
      setEmail(savedEmail)
      setIsLoggedIn(true)
    }
  }, [])

  // Load data from localStorage when logged in
  useEffect(() => {
    if (isLoggedIn) {
      const savedDrugs = localStorage.getItem("mediflux_drugs")
      const savedCustomers = localStorage.getItem("mediflux_customers")
      const savedCustomerTransactions = localStorage.getItem("mediflux_customer_transactions") // Load transactions
      const savedSuppliers = localStorage.getItem("mediflux_suppliers")
      const savedSupplierTransactions = localStorage.getItem("mediflux_supplier_transactions") // Load transactions
      const savedSupplierPayments = localStorage.getItem("mediflux_supplier_payments") // Load payments
      const savedPurchases = localStorage.getItem("mediflux_purchases")
      const savedSales = localStorage.getItem("mediflux_sales")

      if (savedDrugs) setDrugs(JSON.parse(savedDrugs))
      if (savedCustomers) setCustomers(JSON.parse(savedCustomers))
      if (savedCustomerTransactions) setCustomerTransactions(JSON.parse(savedCustomerTransactions))
      if (savedSuppliers) setSuppliers(JSON.parse(savedSuppliers))
      if (savedSupplierTransactions) setSupplierTransactions(JSON.parse(savedSupplierTransactions))
      if (savedSupplierPayments) setSupplierPayments(JSON.parse(savedSupplierPayments))
      if (savedPurchases) setPurchases(JSON.parse(savedPurchases))
      if (savedSales) setSales(JSON.parse(savedSales))
    }
  }, [isLoggedIn])

  // Save data to localStorage
  useEffect(() => {
    if (isLoggedIn) {
      localStorage.setItem("mediflux_drugs", JSON.stringify(drugs))
      localStorage.setItem("mediflux_customers", JSON.stringify(customers))
      localStorage.setItem("mediflux_customer_transactions", JSON.stringify(customerTransactions)) // Save transactions
      localStorage.setItem("mediflux_suppliers", JSON.stringify(suppliers))
      localStorage.setItem("mediflux_supplier_transactions", JSON.stringify(supplierTransactions)) // Save transactions
      localStorage.setItem("mediflux_supplier_payments", JSON.stringify(supplierPayments)) // Save payments
      localStorage.setItem("mediflux_purchases", JSON.stringify(purchases))
      localStorage.setItem("mediflux_sales", JSON.stringify(sales))
    }
  }, [
    drugs,
    customers,
    customerTransactions,
    suppliers,
    supplierTransactions,
    supplierPayments,
    purchases,
    sales,
    isLoggedIn,
  ])

  // Handle login
  const handleLogin = () => {
    if (email && password) {
      setIsLoggedIn(true)
      localStorage.setItem("mediflux_email", email)
      setCurrentPage("home")
    }
  }

  // Handle logout
  const handleLogout = () => {
    setIsLoggedIn(false)
    setEmail("")
    setPassword("")
    localStorage.removeItem("mediflux_email")
    setCurrentPage("home")
  }

  // Drug management
  const addDrug = (drug: Omit<Drug, "id">) => {
    const newDrug = { ...drug, id: Date.now().toString() }
    setDrugs([...drugs, newDrug])
  }

  const deleteDrug = (id: string) => {
    setDrugs(drugs.filter((d) => d.id !== id))
  }

  const addCustomer = (customer: Omit<Customer, "id" | "totalDue" | "totalReceived" | "totalRevenue">) => {
    const newCustomer = {
      ...customer,
      id: Date.now().toString(),
      totalDue: 0,
      totalReceived: 0,
      totalRevenue: 0,
    }
    setCustomers([...customers, newCustomer])
  }

  const deleteCustomer = (id: string) => {
    setCustomers(customers.filter((c) => c.id !== id))
  }

  // Function to add customer transactions (sales, payments)
  const addCustomerTransaction = (transaction: Omit<CustomerTransaction, "id">) => {
    const newTransaction = { ...transaction, id: Date.now().toString() }
    setCustomerTransactions([...customerTransactions, newTransaction])
  }

  const addSupplier = (supplier: Omit<Supplier, "id" | "totalPending" | "totalPaid">) => {
    const newSupplier = {
      ...supplier,
      id: Date.now().toString(),
      totalPending: 0,
      totalPaid: 0,
    }
    setSuppliers([...suppliers, newSupplier])
  }

  const deleteSupplier = (id: string) => {
    setSuppliers(suppliers.filter((s) => s.id !== id))
  }

  // Function to add supplier transactions (purchases, payments)
  const addSupplierTransaction = (transaction: Omit<SupplierTransaction, "id">) => {
    const newTransaction = { ...transaction, id: Date.now().toString() }
    setSupplierTransactions([...supplierTransactions, newTransaction])
  }

  // Function to add supplier payments
  const addSupplierPayment = (payment: Omit<SupplierPayment, "id">) => {
    const newPayment = { ...payment, id: Date.now().toString() }
    setSupplierPayments([...supplierPayments, newPayment])

    const supplier = suppliers.find((s) => s.id === payment.supplierId)
    if (supplier) {
      setSuppliers(
        suppliers.map((s) =>
          s.id === payment.supplierId
            ? {
                ...s,
                totalPending: Math.max(0, s.totalPending - payment.amount),
                totalPaid: s.totalPaid + payment.amount,
              }
            : s,
        ),
      )
    }
  }

  const addPurchase = (purchase: Omit<Purchase, "id">) => {
    const newPurchase = { ...purchase, id: Date.now().toString() }
    setPurchases([...purchases, newPurchase])

    const supplier = suppliers.find((s) => s.id === purchase.supplierId)
    const drug = drugs.find((d) => d.id === purchase.drugId) // Find drug for description
    if (supplier) {
      const amount = purchase.quantity * purchase.price
      setSuppliers(
        suppliers.map((s) =>
          s.id === purchase.supplierId
            ? {
                ...s,
                totalPending: s.totalPending + amount,
              }
            : s,
        ),
      )

      // Add to supplier transaction ledger
      addSupplierTransaction({
        supplierId: purchase.supplierId,
        type: "purchase",
        amount: amount,
        date: purchase.date,
        description: `Purchase Order for ${drug?.name || "Unknown Drug"}`, // More descriptive description
        paymentStatus: "pending",
      })
    }
  }

  const deletePurchase = (id: string) => {
    const purchase = purchases.find((p) => p.id === id)
    if (purchase) {
      const amount = purchase.quantity * purchase.price
      setSuppliers(
        suppliers.map((s) =>
          s.id === purchase.supplierId
            ? {
                ...s,
                totalPending: Math.max(0, s.totalPending - amount),
              }
            : s,
        ),
      )
    }
    setPurchases(purchases.filter((p) => p.id !== id))
  }

  const addSale = (sale: Omit<Sale, "id">) => {
    const newSale = { ...sale, id: Date.now().toString() }
    setSales([...sales, newSale])

    const customer = customers.find((c) => c.id === sale.customerId)
    const drug = drugs.find((d) => d.id === sale.drugId) // Find drug for description
    if (customer) {
      setCustomers(
        customers.map((c) =>
          c.id === sale.customerId
            ? {
                ...c,
                totalDue: c.totalDue + sale.amount,
                totalRevenue: c.totalRevenue + sale.amount,
              }
            : c,
        ),
      )

      // Add to customer transaction ledger
      addCustomerTransaction({
        customerId: sale.customerId,
        type: "sale",
        amount: sale.amount,
        date: sale.date,
        description: `Sale of ${drug?.name || "Unknown Drug"}`, // More descriptive description
        paymentStatus: "due",
      })
    }
  }

  const deleteSale = (id: string) => {
    const sale = sales.find((s) => s.id === id)
    if (sale) {
      setCustomers(
        customers.map((c) =>
          c.id === sale.customerId
            ? {
                ...c,
                totalDue: Math.max(0, c.totalDue - sale.amount),
                totalRevenue: Math.max(0, c.totalRevenue - sale.amount),
              }
            : c,
        ),
      )
    }
    setSales(sales.filter((s) => s.id !== id))
  }

  const updateSalePayment = (id: string, status: string) => {
    const sale = sales.find((s) => s.id === id)
    if (sale) {
      if (status === "received") {
        setCustomers(
          customers.map((c) =>
            c.id === sale.customerId
              ? {
                  ...c,
                  totalDue: Math.max(0, c.totalDue - sale.amount),
                  totalReceived: c.totalReceived + sale.amount,
                }
              : c,
          ),
        )
        // Update customer transaction ledger when payment is received
        setCustomerTransactions(
          customerTransactions.map((t) =>
            t.id === sale.id // Assuming sale.id can be used to find the corresponding transaction
              ? { ...t, paymentStatus: status }
              : t,
          ),
        )
      } else if (status === "partial") {
        const half = sale.amount / 2
        setCustomers(
          customers.map((c) =>
            c.id === sale.customerId
              ? {
                  ...c,
                  totalDue: Math.max(0, c.totalDue - half),
                  totalReceived: c.totalReceived + half,
                }
              : c,
          ),
        )
        // Update customer transaction ledger for partial payment
        setCustomerTransactions(
          customerTransactions.map((t) =>
            t.id === sale.id // Assuming sale.id can be used to find the corresponding transaction
              ? { ...t, paymentStatus: status, amount: half } // Adjust amount for partial payment
              : t,
          ),
        )
      } else {
        // Revert if status is set back to 'due' (though UI might not support this directly)
        // Logic to revert would be more complex and might involve finding original sale amount
      }
    }

    setSales(sales.map((s) => (s.id === id ? { ...s, paymentStatus: status } : s)))
  }

  // Login page
  if (!isLoggedIn && currentPage === "home") {
    return (
      <div className="min-h-screen bg-white">
        {/* Navigation */}
        <nav className="sticky top-0 z-50 bg-white border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="bg-teal-600 p-2 rounded-lg">
                <span className="font-bold text-lg text-white">M</span>
              </div>
              <span className="font-bold text-xl text-gray-900">MediFlux</span>
            </div>
            <Button onClick={() => setCurrentPage("login")} className="bg-teal-600 hover:bg-teal-700 text-white">
              Sign In
            </Button>
          </div>
        </nav>

        {/* Hero Section */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center mb-20">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6 text-balance">
              Pharmacy Management Made Simple
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto text-balance">
              Complete pharmacy billing, inventory management, and reporting system. 100% free forever. No credit card
              required.
            </p>
            <div className="flex gap-4 justify-center flex-wrap">
              <Button
                onClick={() => setCurrentPage("login")}
                className="bg-teal-600 hover:bg-teal-700 text-white px-8 py-6 text-lg"
              >
                Get Started Free
                <ArrowRight className="ml-2" size={20} />
              </Button>
            </div>
          </div>

          {/* Features Section */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 my-20">
            {[
              { title: "GST-Compliant Billing", desc: "Generate accurate invoices with GST calculations" },
              { title: "Smart Inventory", desc: "Track medicine stock with expiry date alerts" },
              { title: "Payment Tracking", desc: "Monitor customer and supplier payments automatically" },
              { title: "Comprehensive Reports", desc: "Get sales, purchase, and profit insights" },
              { title: "Customer Management", desc: "Track customer purchases and receivables" },
              { title: "Supplier Dashboard", desc: "Manage supplier orders and payments" },
            ].map((feature) => (
              <div key={feature.title} className="bg-gray-50 p-8 rounded-lg border border-gray-200">
                <div className="bg-teal-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <Check className="text-teal-600" size={24} />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.desc}</p>
              </div>
            ))}
          </div>

          {/* Testimonials */}
          <div className="bg-gray-50 p-12 rounded-lg my-20">
            <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">What Pharmacists Say</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  name: "Raj Kumar",
                  role: "Pharmacy Owner",
                  text: "MediFlux simplified our billing process. We save hours every week!",
                },
                {
                  name: "Priya Sharma",
                  role: "Pharmacy Manager",
                  text: "The inventory tracking is a game-changer. No more expired medicine.",
                },
                {
                  name: "Amit Patel",
                  role: "Multi-store Owner",
                  text: "Finally, a pharmacy management tool that is actually free and powerful!",
                },
              ].map((testimonial) => (
                <div key={testimonial.name} className="bg-white p-6 rounded-lg border border-gray-200">
                  <p className="text-gray-700 mb-4">"{testimonial.text}"</p>
                  <p className="font-bold text-gray-900">{testimonial.name}</p>
                  <p className="text-sm text-gray-600">{testimonial.role}</p>
                </div>
              ))}
            </div>
          </div>

          {/* CTA Section */}
          <div className="bg-teal-600 text-white p-12 rounded-lg text-center my-20">
            <h2 className="text-3xl font-bold mb-4">Ready to streamline your pharmacy?</h2>
            <p className="text-lg mb-8 text-teal-50">
              Start managing your pharmacy like a pro. It only takes 2 minutes to get started.
            </p>
            <Button
              onClick={() => setCurrentPage("login")}
              className="bg-white text-teal-600 hover:bg-gray-100 px-8 py-6 text-lg"
            >
              Start Free Trial
            </Button>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-gray-900 text-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <p className="text-gray-400">© 2025 MediFlux. Free pharmacy management software.</p>
          </div>
        </footer>
      </div>
    )
  }

  // Login Page
  if (!isLoggedIn && currentPage === "login") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-teal-50 to-teal-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-2xl p-8 w-full max-w-md">
          <div className="flex items-center gap-3 mb-8">
            <div className="bg-teal-600 p-2 rounded-lg">
              <span className="font-bold text-lg text-white">M</span>
            </div>
            <h1 className="text-2xl font-bold text-gray-900">MediFlux</h1>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
              <Input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
              <Input
                type={showPassword ? "text" : "password"}
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full"
              />
            </div>

            <Button
              onClick={handleLogin}
              className="w-full bg-teal-600 hover:bg-teal-700 text-white py-3 rounded-lg font-medium text-lg"
            >
              Sign In
            </Button>
          </div>

          <div className="mt-6 pt-6 border-t border-gray-200">
            <p className="text-center text-sm text-gray-600">Demo account: Use any email and password to login</p>
          </div>

          <button
            onClick={() => {
              setCurrentPage("home")
              setEmail("")
              setPassword("")
            }}
            className="w-full mt-4 text-teal-600 hover:text-teal-700 font-medium"
          >
            ← Back to Home
          </button>
        </div>
      </div>
    )
  }

  // Dashboard
  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div
        className={`${
          sidebarOpen ? "w-64" : "w-20"
        } bg-teal-600 text-white transition-all duration-300 overflow-y-auto flex flex-col`}
      >
        <div className="p-4 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="bg-teal-700 p-2 rounded-lg">
              <span className="font-bold text-lg">M</span>
            </div>
            {sidebarOpen && <span className="font-bold">MediFlux</span>}
          </div>
        </div>

        <nav className="flex-1 mt-8 space-y-2 px-2">
          {[
            { icon: HomeIcon, label: "Home", id: "home", subItems: [] },
            {
              icon: Pill,
              label: "Drugs",
              id: "drugs",
              subItems: [
                { label: "Drug List", id: "drug-list" },
                { label: "Add Drug", id: "add-drug" },
                { label: "Categories", id: "categories" }, // Placeholder for future implementation
                { label: "Expiry Tracking", id: "expiry" },
              ],
            },
            {
              icon: Users,
              label: "Customers",
              id: "customers",
              subItems: [
                { label: "Customer List", id: "customer-list" },
                { label: "Add Customer", id: "add-customer" },
                { label: "Ledger", id: "customer-ledger" },
                { label: "Payments", id: "customer-payments" },
              ],
            },
            {
              icon: Building2,
              label: "Suppliers",
              id: "suppliers",
              subItems: [
                { label: "Supplier List", id: "supplier-list" },
                { label: "Add Supplier", id: "add-supplier" },
                { label: "Ledger", id: "supplier-ledger" },
                { label: "Payments", id: "supplier-payments" },
              ],
            },
            {
              icon: ShoppingCart,
              label: "Purchases",
              id: "purchases",
              subItems: [
                { label: "Purchase List", id: "purchase-list" },
                { label: "New Purchase", id: "new-purchase" },
                { label: "History", id: "purchase-history" }, // Placeholder
              ],
            },
            {
              icon: TrendingUp,
              label: "Sales",
              id: "sales",
              subItems: [
                { label: "Sales Dashboard", id: "sales-dashboard" }, // Placeholder
                { label: "New Sale", id: "new-sale" },
                { label: "History", id: "sales-history" },
              ],
            },
            { icon: FileText, label: "Reports", id: "reports", subItems: [] },
          ].map((item) => (
            <div key={item.id}>
              <button
                onClick={() => {
                  if (item.subItems.length > 0) {
                    setExpandedMenu(expandedMenu === item.id ? null : item.id)
                  } else {
                    setCurrentPage(item.id)
                    setCurrentSubPage("")
                  }
                }}
                className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors ${
                  currentPage === item.id ? "bg-teal-700" : "hover:bg-teal-700"
                }`}
              >
                <item.icon size={20} />
                {sidebarOpen && (
                  <>
                    <span>{item.label}</span>
                    {item.subItems.length > 0 && (
                      <ChevronDown
                        size={16}
                        className={`ml-auto transition-transform ${expandedMenu === item.id ? "rotate-180" : ""}`}
                      />
                    )}
                  </>
                )}
              </button>

              {sidebarOpen && expandedMenu === item.id && item.subItems.length > 0 && (
                <div className="bg-teal-700 rounded-lg mt-1 py-2">
                  {item.subItems.map((subItem) => (
                    <button
                      key={subItem.id}
                      onClick={() => {
                        setCurrentPage(item.id)
                        setCurrentSubPage(subItem.id)
                      }}
                      className={`w-full text-left px-6 py-2 text-sm transition-colors ${
                        currentSubPage === subItem.id ? "bg-teal-800 text-white" : "hover:bg-teal-600"
                      }`}
                    >
                      {subItem.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>

        <div className="p-2 flex-shrink-0">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-teal-700 transition-colors text-sm"
          >
            <LogOut size={20} />
            {sidebarOpen && <span>Logout</span>}
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <div className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-gray-600 hover:text-gray-900">
            {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
          <div className="text-sm text-gray-600">
            Logged in as <span className="font-medium">{email}</span>
          </div>
        </div>

        {/* Page Content */}
        <div className="flex-1 overflow-auto p-6">
          {currentPage === "home" && (
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-6">Dashboard</h1>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                <div className="bg-white p-6 rounded-lg shadow border-l-4 border-teal-600">
                  <p className="text-gray-600 text-sm font-medium mb-2">Total Drugs</p>
                  <p className="text-3xl font-bold text-teal-600">{drugs.length}</p>
                </div>

                <div className="bg-white p-6 rounded-lg shadow border-l-4 border-blue-600">
                  <p className="text-gray-600 text-sm font-medium mb-2">Total Customers</p>
                  <p className="text-3xl font-bold text-blue-600">{customers.length}</p>
                </div>

                <div className="bg-white p-6 rounded-lg shadow border-l-4 border-orange-600">
                  <p className="text-gray-600 text-sm font-medium mb-2">Total Due</p>
                  <p className="text-3xl font-bold text-orange-600">
                    ₹{customers.reduce((sum, c) => sum + c.totalDue, 0).toLocaleString()}
                  </p>
                </div>

                <div className="bg-white p-6 rounded-lg shadow border-l-4 border-red-600">
                  <p className="text-gray-600 text-sm font-medium mb-2">Total Payable</p>
                  <p className="text-3xl font-bold text-red-600">
                    ₹{suppliers.reduce((sum, s) => sum + s.totalPending, 0).toLocaleString()}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-lg shadow">
                  <h3 className="text-lg font-bold text-gray-900 mb-4">Sales Summary</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total Sales</span>
                      <span className="font-bold">₹{sales.reduce((sum, s) => sum + s.amount, 0).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total Received</span>
                      <span className="font-bold text-green-600">
                        ₹{customers.reduce((sum, c) => sum + c.totalReceived, 0).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Outstanding Due</span>
                      <span className="font-bold text-orange-600">
                        ₹{customers.reduce((sum, c) => sum + c.totalDue, 0).toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-lg shadow">
                  <h3 className="text-lg font-bold text-gray-900 mb-4">Purchase Summary</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total Purchases</span>
                      <span className="font-bold">
                        ₹{purchases.reduce((sum, p) => sum + p.quantity * p.price, 0).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total Paid</span>
                      <span className="font-bold text-green-600">
                        ₹{suppliers.reduce((sum, s) => sum + s.totalPaid, 0).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Outstanding Payable</span>
                      <span className="font-bold text-red-600">
                        ₹{suppliers.reduce((sum, s) => sum + s.totalPending, 0).toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* DRUGS SECTION */}
          {currentPage === "drugs" && currentSubPage === "drug-list" && (
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-6">Drug List</h1>
              <div className="bg-white rounded-lg shadow overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Name</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Category</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Qty</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Price</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Expiry</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Batch</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {drugs.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="px-6 py-8 text-center text-gray-500">
                          No drugs added yet.
                        </td>
                      </tr>
                    ) : (
                      drugs.map((drug) => (
                        <tr key={drug.id} className="border-b hover:bg-gray-50">
                          <td className="px-6 py-3 text-sm">{drug.name}</td>
                          <td className="px-6 py-3 text-sm">{drug.category}</td>
                          <td className="px-6 py-3 text-sm">{drug.quantity}</td>
                          <td className="px-6 py-3 text-sm">₹{drug.price}</td>
                          <td className="px-6 py-3 text-sm">{drug.expiryDate}</td>
                          <td className="px-6 py-3 text-sm">{drug.batchNumber}</td>
                          <td className="px-6 py-3 text-sm">
                            <button
                              onClick={() => deleteDrug(drug.id)}
                              className="text-red-600 hover:text-red-800 text-sm font-medium"
                            >
                              Delete
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {currentPage === "drugs" && currentSubPage === "add-drug" && (
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-6">Add New Drug</h1>
              <div className="bg-white p-6 rounded-lg shadow max-w-2xl">
                <form
                  onSubmit={(e) => {
                    e.preventDefault()
                    const formData = new FormData(e.currentTarget)
                    addDrug({
                      name: formData.get("name") as string,
                      category: formData.get("category") as string,
                      quantity: Number(formData.get("quantity")),
                      price: Number(formData.get("price")),
                      expiryDate: formData.get("expiryDate") as string,
                      batchNumber: formData.get("batchNumber") as string,
                    })
                    e.currentTarget.reset()
                  }}
                  className="space-y-4"
                >
                  <div className="grid grid-cols-2 gap-4">
                    <Input type="text" name="name" placeholder="Drug Name" required />
                    <Input type="text" name="category" placeholder="Category" required />
                    <Input type="number" name="quantity" placeholder="Quantity" required />
                    <Input type="number" name="price" placeholder="Price per unit" required />
                    <Input type="date" name="expiryDate" required />
                    <Input type="text" name="batchNumber" placeholder="Batch Number" required />
                  </div>
                  <Button type="submit" className="w-full bg-teal-600 hover:bg-teal-700 text-white">
                    Add Drug
                  </Button>
                </form>
              </div>
            </div>
          )}

          {currentPage === "drugs" && currentSubPage === "expiry" && (
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-6">Expiry Tracking</h1>
              <div className="bg-white rounded-lg shadow overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Drug Name</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Batch</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Expiry Date</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Status</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Qty</th>
                    </tr>
                  </thead>
                  <tbody>
                    {drugs.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="px-6 py-8 text-center text-gray-500">
                          No drugs to track.
                        </td>
                      </tr>
                    ) : (
                      drugs.map((drug) => {
                        const today = new Date()
                        const expiryDate = new Date(drug.expiryDate)
                        const daysLeft = Math.floor((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
                        const status = daysLeft < 0 ? "Expired" : daysLeft < 30 ? "Warning" : "OK"
                        const statusColor =
                          status === "Expired"
                            ? "text-red-600"
                            : status === "Warning"
                              ? "text-yellow-600"
                              : "text-green-600"

                        return (
                          <tr key={drug.id} className="border-b hover:bg-gray-50">
                            <td className="px-6 py-3 text-sm font-medium">{drug.name}</td>
                            <td className="px-6 py-3 text-sm">{drug.batchNumber}</td>
                            <td className="px-6 py-3 text-sm">{drug.expiryDate}</td>
                            <td className={`px-6 py-3 text-sm font-bold ${statusColor}`}>{status}</td>
                            <td className="px-6 py-3 text-sm">{drug.quantity}</td>
                          </tr>
                        )
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* CUSTOMERS SECTION */}
          {currentPage === "customers" && currentSubPage === "customer-list" && (
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-6">Customer List</h1>
              <div className="bg-white rounded-lg shadow overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Name</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Phone</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Email</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Total Due</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Total Received</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {customers.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-6 py-8 text-center text-gray-500">
                          No customers added yet.
                        </td>
                      </tr>
                    ) : (
                      customers.map((customer) => (
                        <tr key={customer.id} className="border-b hover:bg-gray-50">
                          <td className="px-6 py-3 text-sm font-medium">{customer.name}</td>
                          <td className="px-6 py-3 text-sm">{customer.phone}</td>
                          <td className="px-6 py-3 text-sm">{customer.email}</td>
                          <td className="px-6 py-3 text-sm font-bold text-orange-600">
                            ₹{customer.totalDue.toLocaleString()}
                          </td>
                          <td className="px-6 py-3 text-sm font-bold text-green-600">
                            ₹{customer.totalReceived.toLocaleString()}
                          </td>
                          <td className="px-6 py-3 text-sm">
                            <button
                              onClick={() => deleteCustomer(customer.id)}
                              className="text-red-600 hover:text-red-800 font-medium"
                            >
                              Delete
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {currentPage === "customers" && currentSubPage === "add-customer" && (
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-6">Add New Customer</h1>
              <div className="bg-white p-6 rounded-lg shadow max-w-2xl">
                <form
                  onSubmit={(e) => {
                    e.preventDefault()
                    const formData = new FormData(e.currentTarget)
                    addCustomer({
                      name: formData.get("name") as string,
                      phone: formData.get("phone") as string,
                      email: formData.get("email") as string,
                      address: formData.get("address") as string,
                    })
                    e.currentTarget.reset()
                  }}
                  className="space-y-4"
                >
                  <div className="grid grid-cols-2 gap-4">
                    <Input type="text" name="name" placeholder="Customer Name" required />
                    <Input type="tel" name="phone" placeholder="Phone" required />
                    <Input type="email" name="email" placeholder="Email" required />
                    <Input type="text" name="address" placeholder="Address" required />
                  </div>
                  <Button type="submit" className="w-full bg-teal-600 hover:bg-teal-700 text-white">
                    Add Customer
                  </Button>
                </form>
              </div>
            </div>
          )}

          {currentPage === "customers" && currentSubPage === "customer-ledger" && (
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-6">Customer Ledger</h1>
              <div className="space-y-6">
                {customers.map((customer) => {
                  const customerTxns = customerTransactions.filter((t) => t.customerId === customer.id)
                  return (
                    <div key={customer.id} className="bg-white p-6 rounded-lg shadow">
                      <h3 className="text-lg font-bold text-gray-900 mb-4">{customer.name}</h3>
                      <div className="grid grid-cols-3 gap-4 mb-4">
                        <div className="bg-gray-50 p-4 rounded">
                          <p className="text-sm text-gray-600">Total Due</p>
                          <p className="text-2xl font-bold text-orange-600">₹{customer.totalDue.toLocaleString()}</p>
                        </div>
                        <div className="bg-gray-50 p-4 rounded">
                          <p className="text-sm text-gray-600">Total Received</p>
                          <p className="text-2xl font-bold text-green-600">
                            ₹{customer.totalReceived.toLocaleString()}
                          </p>
                        </div>
                        <div className="bg-gray-50 p-4 rounded">
                          <p className="text-sm text-gray-600">Total Revenue</p>
                          <p className="text-2xl font-bold text-blue-600">₹{customer.totalRevenue.toLocaleString()}</p>
                        </div>
                      </div>
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead className="bg-gray-50">
                            <tr>
                              <th className="px-4 py-2 text-left">Date</th>
                              <th className="px-4 py-2 text-left">Type</th>
                              <th className="px-4 py-2 text-left">Amount</th>
                              <th className="px-4 py-2 text-left">Status</th>
                            </tr>
                          </thead>
                          <tbody>
                            {customerTxns.length === 0 ? (
                              <tr>
                                <td colSpan={4} className="px-4 py-4 text-center text-gray-500">
                                  No transactions
                                </td>
                              </tr>
                            ) : (
                              customerTxns.map((txn) => (
                                <tr key={txn.id} className="border-b">
                                  <td className="px-4 py-2">{txn.date}</td>
                                  <td className="px-4 py-2 capitalize">{txn.type}</td>
                                  <td className="px-4 py-2 font-bold">₹{txn.amount.toLocaleString()}</td>
                                  <td className="px-4 py-2 capitalize text-sm">{txn.paymentStatus}</td>
                                </tr>
                              ))
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {currentPage === "customers" && currentSubPage === "customer-payments" && (
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-6">Customer Payments</h1>
              <div className="bg-white p-6 rounded-lg shadow max-w-2xl mb-6">
                <h2 className="text-lg font-bold mb-4">Record Payment</h2>
                <form
                  onSubmit={(e) => {
                    e.preventDefault()
                    const formData = new FormData(e.currentTarget)
                    const customerId = formData.get("customerId") as string
                    const amount = Number(formData.get("amount"))
                    const date = formData.get("date") as string

                    const customer = customers.find((c) => c.id === customerId)
                    if (customer && amount > 0) {
                      const newDue = Math.max(0, customer.totalDue - amount)
                      setCustomers(
                        customers.map((c) =>
                          c.id === customerId
                            ? {
                                ...c,
                                totalDue: newDue,
                                totalReceived: c.totalReceived + amount,
                              }
                            : c,
                        ),
                      )

                      addCustomerTransaction({
                        customerId,
                        type: "payment",
                        amount,
                        date,
                        description: "Payment Received",
                        paymentStatus: "received",
                      })

                      e.currentTarget.reset()
                    }
                  }}
                  className="space-y-4"
                >
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Customer</label>
                    <select name="customerId" required className="w-full border border-gray-300 rounded-lg p-2">
                      <option value="">Select Customer</option>
                      {customers.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name} (Due: ₹{c.totalDue})
                        </option>
                      ))}
                    </select>
                  </div>
                  <Input type="number" name="amount" placeholder="Payment Amount" required />
                  <Input type="date" name="date" required />
                  <Button type="submit" className="w-full bg-teal-600 hover:bg-teal-700 text-white">
                    Record Payment
                  </Button>
                </form>
              </div>
            </div>
          )}

          {/* SUPPLIERS SECTION */}
          {currentPage === "suppliers" && currentSubPage === "supplier-list" && (
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-6">Supplier List</h1>
              <div className="bg-white rounded-lg shadow overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Name</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Phone</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Email</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Total Pending</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Total Paid</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {suppliers.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-6 py-8 text-center text-gray-500">
                          No suppliers added yet.
                        </td>
                      </tr>
                    ) : (
                      suppliers.map((supplier) => (
                        <tr key={supplier.id} className="border-b hover:bg-gray-50">
                          <td className="px-6 py-3 text-sm font-medium">{supplier.name}</td>
                          <td className="px-6 py-3 text-sm">{supplier.phone}</td>
                          <td className="px-6 py-3 text-sm">{supplier.email}</td>
                          <td className="px-6 py-3 text-sm font-bold text-red-600">
                            ₹{supplier.totalPending.toLocaleString()}
                          </td>
                          <td className="px-6 py-3 text-sm font-bold text-green-600">
                            ₹{supplier.totalPaid.toLocaleString()}
                          </td>
                          <td className="px-6 py-3 text-sm">
                            <button
                              onClick={() => deleteSupplier(supplier.id)}
                              className="text-red-600 hover:text-red-800 font-medium"
                            >
                              Delete
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {currentPage === "suppliers" && currentSubPage === "add-supplier" && (
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-6">Add New Supplier</h1>
              <div className="bg-white p-6 rounded-lg shadow max-w-2xl">
                <form
                  onSubmit={(e) => {
                    e.preventDefault()
                    const formData = new FormData(e.currentTarget)
                    addSupplier({
                      name: formData.get("name") as string,
                      phone: formData.get("phone") as string,
                      email: formData.get("email") as string,
                      city: formData.get("city") as string,
                    })
                    e.currentTarget.reset()
                  }}
                  className="space-y-4"
                >
                  <div className="grid grid-cols-2 gap-4">
                    <Input type="text" name="name" placeholder="Supplier Name" required />
                    <Input type="tel" name="phone" placeholder="Phone" required />
                    <Input type="email" name="email" placeholder="Email" required />
                    <Input type="text" name="city" placeholder="City" required />
                  </div>
                  <Button type="submit" className="w-full bg-teal-600 hover:bg-teal-700 text-white">
                    Add Supplier
                  </Button>
                </form>
              </div>
            </div>
          )}

          {currentPage === "suppliers" && currentSubPage === "supplier-ledger" && (
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-6">Supplier Ledger</h1>
              <div className="space-y-6">
                {suppliers.map((supplier) => {
                  const supplierTxns = supplierTransactions.filter((t) => t.supplierId === supplier.id)
                  return (
                    <div key={supplier.id} className="bg-white p-6 rounded-lg shadow">
                      <h3 className="text-lg font-bold text-gray-900 mb-4">{supplier.name}</h3>
                      <div className="grid grid-cols-3 gap-4 mb-4">
                        <div className="bg-gray-50 p-4 rounded">
                          <p className="text-sm text-gray-600">Total Pending</p>
                          <p className="text-2xl font-bold text-red-600">₹{supplier.totalPending.toLocaleString()}</p>
                        </div>
                        <div className="bg-gray-50 p-4 rounded">
                          <p className="text-sm text-gray-600">Total Paid</p>
                          <p className="text-2xl font-bold text-green-600">₹{supplier.totalPaid.toLocaleString()}</p>
                        </div>
                        <div className="bg-gray-50 p-4 rounded">
                          <p className="text-sm text-gray-600">Total Payable</p>
                          <p className="text-2xl font-bold text-blue-600">
                            ₹{(supplier.totalPending + supplier.totalPaid).toLocaleString()}
                          </p>
                        </div>
                      </div>
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead className="bg-gray-50">
                            <tr>
                              <th className="px-4 py-2 text-left">Date</th>
                              <th className="px-4 py-2 text-left">Type</th>
                              <th className="px-4 py-2 text-left">Amount</th>
                              <th className="px-4 py-2 text-left">Status</th>
                            </tr>
                          </thead>
                          <tbody>
                            {supplierTxns.length === 0 ? (
                              <tr>
                                <td colSpan={4} className="px-4 py-4 text-center text-gray-500">
                                  No transactions
                                </td>
                              </tr>
                            ) : (
                              supplierTxns.map((txn) => (
                                <tr key={txn.id} className="border-b">
                                  <td className="px-4 py-2">{txn.date}</td>
                                  <td className="px-4 py-2 capitalize">{txn.type}</td>
                                  <td className="px-4 py-2 font-bold">₹{txn.amount.toLocaleString()}</td>
                                  <td className="px-4 py-2 capitalize text-sm">{txn.paymentStatus}</td>
                                </tr>
                              ))
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {currentPage === "suppliers" && currentSubPage === "supplier-payments" && (
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-6">Supplier Payments</h1>
              <div className="bg-white p-6 rounded-lg shadow max-w-2xl mb-6">
                <h2 className="text-lg font-bold mb-4">Add Payment</h2>
                <form
                  onSubmit={(e) => {
                    e.preventDefault()
                    const formData = new FormData(e.currentTarget)
                    addSupplierPayment({
                      supplierId: formData.get("supplierId") as string,
                      amount: Number(formData.get("amount")),
                      date: formData.get("date") as string,
                      paymentMethod: formData.get("paymentMethod") as string,
                      referenceNo: formData.get("referenceNo") as string,
                    })
                    e.currentTarget.reset()
                  }}
                  className="space-y-4"
                >
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Supplier</label>
                    <select name="supplierId" required className="w-full border border-gray-300 rounded-lg p-2">
                      <option value="">Select Supplier</option>
                      {suppliers.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name} (Pending: ₹{s.totalPending})
                        </option>
                      ))}
                    </select>
                  </div>
                  <Input type="number" name="amount" placeholder="Payment Amount" required />
                  <Input type="date" name="date" required />
                  <select name="paymentMethod" required className="w-full border border-gray-300 rounded-lg p-2">
                    <option value="">Select Payment Method</option>
                    <option value="cash">Cash</option>
                    <option value="check">Check</option>
                    <option value="bank_transfer">Bank Transfer</option>
                    <option value="online">Online</option>
                  </select>
                  <Input type="text" name="referenceNo" placeholder="Reference/Cheque No" />
                  <Button type="submit" className="w-full bg-teal-600 hover:bg-teal-700 text-white">
                    Add Payment
                  </Button>
                </form>
              </div>

              <div className="bg-white rounded-lg shadow overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Supplier</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Amount</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Date</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Method</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Ref No</th>
                    </tr>
                  </thead>
                  <tbody>
                    {supplierPayments.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="px-6 py-8 text-center text-gray-500">
                          No payments recorded yet.
                        </td>
                      </tr>
                    ) : (
                      supplierPayments.map((payment) => {
                        const supplier = suppliers.find((s) => s.id === payment.supplierId)
                        return (
                          <tr key={payment.id} className="border-b hover:bg-gray-50">
                            <td className="px-6 py-3 text-sm font-medium">{supplier?.name}</td>
                            <td className="px-6 py-3 text-sm font-bold">₹{payment.amount.toLocaleString()}</td>
                            <td className="px-6 py-3 text-sm">{payment.date}</td>
                            <td className="px-6 py-3 text-sm capitalize">{payment.paymentMethod}</td>
                            <td className="px-6 py-3 text-sm">{payment.referenceNo}</td>
                          </tr>
                        )
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* PURCHASES SECTION */}
          {currentPage === "purchases" && currentSubPage === "purchase-list" && (
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-6">Purchase List</h1>
              <div className="bg-white rounded-lg shadow overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Supplier</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Drug</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Qty</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Amount</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Date</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Status</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {purchases.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="px-6 py-8 text-center text-gray-500">
                          No purchases created yet.
                        </td>
                      </tr>
                    ) : (
                      purchases.map((purchase) => {
                        const supplier = suppliers.find((s) => s.id === purchase.supplierId)
                        const drug = drugs.find((d) => d.id === purchase.drugId)
                        return (
                          <tr key={purchase.id} className="border-b hover:bg-gray-50">
                            <td className="px-6 py-3 text-sm font-medium">{supplier?.name}</td>
                            <td className="px-6 py-3 text-sm">{drug?.name}</td>
                            <td className="px-6 py-3 text-sm">{purchase.quantity}</td>
                            <td className="px-6 py-3 text-sm font-bold">
                              ₹{(purchase.quantity * purchase.price).toLocaleString()}
                            </td>
                            <td className="px-6 py-3 text-sm">{purchase.date}</td>
                            <td className="px-6 py-3 text-sm capitalize">{purchase.paymentStatus}</td>
                            <td className="px-6 py-3 text-sm">
                              <button
                                onClick={() => deletePurchase(purchase.id)}
                                className="text-red-600 hover:text-red-800 font-medium"
                              >
                                Delete
                              </button>
                            </td>
                          </tr>
                        )
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {currentPage === "purchases" && currentSubPage === "new-purchase" && (
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-6">New Purchase Order</h1>
              <div className="bg-white p-6 rounded-lg shadow max-w-2xl">
                <form
                  onSubmit={(e) => {
                    e.preventDefault()
                    const formData = new FormData(e.currentTarget)
                    addPurchase({
                      supplierId: formData.get("supplierId") as string,
                      drugId: formData.get("drugId") as string,
                      quantity: Number(formData.get("quantity")),
                      price: Number(formData.get("price")),
                      date: formData.get("date") as string,
                      paymentStatus: "pending",
                    })
                    e.currentTarget.reset()
                  }}
                  className="space-y-4"
                >
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Supplier</label>
                    <select name="supplierId" required className="w-full border border-gray-300 rounded-lg p-2">
                      <option value="">Select Supplier</option>
                      {suppliers.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Drug</label>
                    <select name="drugId" required className="w-full border border-gray-300 rounded-lg p-2">
                      <option value="">Select Drug</option>
                      {drugs.map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <Input type="number" name="quantity" placeholder="Quantity" required />
                  <Input type="number" name="price" placeholder="Price per unit" required />
                  <Input type="date" name="date" required />
                  <Button type="submit" className="w-full bg-teal-600 hover:bg-teal-700 text-white">
                    Create Purchase Order
                  </Button>
                </form>
              </div>
            </div>
          )}

          {/* SALES SECTION */}
          {currentPage === "sales" && currentSubPage === "new-sale" && (
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-6">New Sale</h1>
              <div className="bg-white p-6 rounded-lg shadow max-w-2xl">
                <form
                  onSubmit={(e) => {
                    e.preventDefault()
                    const formData = new FormData(e.currentTarget)
                    addSale({
                      customerId: formData.get("customerId") as string,
                      drugId: formData.get("drugId") as string,
                      quantity: Number(formData.get("quantity")),
                      amount: Number(formData.get("amount")),
                      date: formData.get("date") as string,
                      paymentStatus: "due",
                    })
                    e.currentTarget.reset()
                  }}
                  className="space-y-4"
                >
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Customer</label>
                    <select name="customerId" required className="w-full border border-gray-300 rounded-lg p-2">
                      <option value="">Select Customer</option>
                      {customers.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Drug</label>
                    <select name="drugId" required className="w-full border border-gray-300 rounded-lg p-2">
                      <option value="">Select Drug</option>
                      {drugs.map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <Input type="number" name="quantity" placeholder="Quantity" required />
                  <Input type="number" name="amount" placeholder="Sale Amount" required />
                  <Input type="date" name="date" required />
                  <Button type="submit" className="w-full bg-teal-600 hover:bg-teal-700 text-white">
                    Create Sale
                  </Button>
                </form>
              </div>
            </div>
          )}

          {currentPage === "sales" && currentSubPage === "sales-history" && (
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-6">Sales History</h1>
              <div className="bg-white rounded-lg shadow overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Customer</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Drug</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Qty</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Amount</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Date</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Status</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sales.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="px-6 py-8 text-center text-gray-500">
                          No sales created yet.
                        </td>
                      </tr>
                    ) : (
                      sales.map((sale) => {
                        const customer = customers.find((c) => c.id === sale.customerId)
                        const drug = drugs.find((d) => d.id === sale.drugId)
                        return (
                          <tr key={sale.id} className="border-b hover:bg-gray-50">
                            <td className="px-6 py-3 text-sm font-medium">{customer?.name}</td>
                            <td className="px-6 py-3 text-sm">{drug?.name}</td>
                            <td className="px-6 py-3 text-sm">{sale.quantity}</td>
                            <td className="px-6 py-3 text-sm font-bold">₹{sale.amount.toLocaleString()}</td>
                            <td className="px-6 py-3 text-sm">{sale.date}</td>
                            <td className="px-6 py-3 text-sm">
                              <select
                                value={sale.paymentStatus}
                                onChange={(e) => updateSalePayment(sale.id, e.target.value)}
                                className="border border-gray-300 rounded px-2 py-1 text-sm"
                              >
                                <option value="due">Due</option>
                                <option value="partial">Partial</option>
                                <option value="received">Received</option>
                              </select>
                            </td>
                            <td className="px-6 py-3 text-sm">
                              <button
                                onClick={() => deleteSale(sale.id)}
                                className="text-red-600 hover:text-red-800 font-medium"
                              >
                                Delete
                              </button>
                            </td>
                          </tr>
                        )
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {currentPage === "reports" && (
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-6">Reports & Analytics</h1>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-lg shadow">
                  <h3 className="text-lg font-bold text-gray-900 mb-4">Sales Summary</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between pb-3 border-b">
                      <span className="text-gray-600">Total Sales</span>
                      <span className="font-bold">₹{sales.reduce((sum, s) => sum + s.amount, 0).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between pb-3 border-b">
                      <span className="text-gray-600">Total Received</span>
                      <span className="font-bold text-green-600">
                        ₹{customers.reduce((sum, c) => sum + c.totalReceived, 0).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between pb-3 border-b">
                      <span className="text-gray-600">Total Due</span>
                      <span className="font-bold text-orange-600">
                        ₹{customers.reduce((sum, c) => sum + c.totalDue, 0).toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-lg shadow">
                  <h3 className="text-lg font-bold text-gray-900 mb-4">Purchase Summary</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between pb-3 border-b">
                      <span className="text-gray-600">Total Purchases</span>
                      <span className="font-bold">
                        ₹{purchases.reduce((sum, p) => sum + p.quantity * p.price, 0).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between pb-3 border-b">
                      <span className="text-gray-600">Total Paid</span>
                      <span className="font-bold text-green-600">
                        ₹{suppliers.reduce((sum, s) => sum + s.totalPaid, 0).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between pb-3 border-b">
                      <span className="text-gray-600">Total Pending</span>
                      <span className="font-bold text-red-600">
                        ₹{suppliers.reduce((sum, s) => sum + s.totalPending, 0).toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
