"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Pill, Check, Star, ChevronRight } from "lucide-react"

interface LandingPageProps {
  onGetStarted: () => void
}

export default function LandingPage({ onGetStarted }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted">
      {/* Navigation */}
      <nav className="bg-background border-b border-border sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 md:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Pill className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold">MediFlux</span>
          </div>
          <Button onClick={onGetStarted} className="bg-primary hover:bg-primary text-primary-foreground">
            Get Started Free
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-6xl mx-auto px-4 md:px-8 py-20 md:py-32">
        <div className="text-center space-y-6 mb-12">
          <h1 className="text-4xl md:text-6xl font-bold text-balance">Manage Your Pharmacy With Ease and Precision</h1>
          <p className="text-lg md:text-xl text-muted-foreground text-balance">
            Effortlessly manage GST-compliant billing and streamline your pharmacy's operations with MediFlux. All
            features included for ₹3,500/year.
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Button
              onClick={onGetStarted}
              size="lg"
              className="bg-primary hover:bg-primary text-primary-foreground gap-2"
            >
              Try MediFlux Free <ChevronRight className="w-4 h-4" />
            </Button>
            <Button size="lg" variant="outline">
              Watch Demo
            </Button>
          </div>
        </div>

        {/* Hero Image */}
        <div className="bg-gradient-to-b from-primary/10 to-transparent rounded-lg h-64 md:h-96 flex items-center justify-center border border-primary/20">
          <div className="text-6xl">💊</div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-card py-20">
        <div className="max-w-6xl mx-auto px-4 md:px-8">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center text-balance">
            Powerful Features Built for Real Pharmacy Needs
          </h2>
          <p className="text-center text-muted-foreground mb-16 text-balance">
            From billing to stock and reports, everything your medical store needs
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                title: "GST-Ready Billing",
                description: "Generate tax-ready bills in seconds with automatic GST compliance",
                icon: "💳",
              },
              {
                title: "Smart Inventory",
                description: "Track medicines with batch numbers, expiry dates, and low stock alerts",
                icon: "📦",
              },
              {
                title: "WhatsApp Integration",
                description: "Send bills instantly to customers via WhatsApp with one click",
                icon: "💬",
              },
              {
                title: "Comprehensive Reporting",
                description: "Generate insightful reports to monitor sales and performance",
                icon: "📈",
              },
              {
                title: "Expiry & Low Stock",
                description: "Receive real-time alerts for expiring drugs and low stock levels",
                icon: "🚨",
              },
              {
                title: "Quick Drug Fill",
                description: "Add inventory in seconds with streamlined quick entry feature",
                icon: "⚡",
              },
            ].map((feature, idx) => (
              <Card key={idx} className="p-6 hover:shadow-lg transition-shadow">
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-4 md:px-8">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center text-balance">Simple, Transparent Pricing</h2>
          <p className="text-center text-muted-foreground mb-16 text-balance">
            One comprehensive plan with everything your pharmacy needs
          </p>

          <div className="max-w-2xl mx-auto">
            <Card className="p-8 bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
              <div className="text-center mb-8">
                <div className="text-5xl font-bold mb-2">₹3,500</div>
                <p className="text-lg text-muted-foreground">per year • All features included</p>
              </div>

              <div className="space-y-4 mb-8">
                {[
                  "Unlimited users and devices",
                  "Unlimited medicines and customers",
                  "GST-compliant billing",
                  "Expiry and low stock alerts",
                  "WhatsApp bill sharing",
                  "Cloud backup and sync",
                  "Real-time support via phone & chat",
                  "Free updates forever",
                  "No hidden charges",
                ].map((feature, idx) => (
                  <div key={idx} className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-600" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>

              <Button
                onClick={onGetStarted}
                size="lg"
                className="w-full bg-primary hover:bg-primary text-primary-foreground"
              >
                Get Started Free
              </Button>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-card py-20">
        <div className="max-w-6xl mx-auto px-4 md:px-8">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center text-balance">What Our Users Say</h2>
          <p className="text-center text-muted-foreground mb-16">Trusted by 1000+ pharmacies across India</p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                name: "Aamir Malik",
                pharmacy: "Malik Medicate",
                quote:
                  "MediFlux is incredibly user-friendly! Even my staff with no technical knowledge can navigate it easily.",
              },
              {
                name: "Farhan Shah",
                pharmacy: "Shah Medical Store",
                quote: "The quick drug fill feature makes inventory management easier and saves us valuable time.",
              },
              {
                name: "Javaid Lone",
                pharmacy: "Best Care Medicate",
                quote:
                  "Managing GST billing has never been easier. MediFlux simplifies everything without requiring technical skills.",
              },
            ].map((testimonial, idx) => (
              <Card key={idx} className="p-6">
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-muted-foreground mb-4">{testimonial.quote}</p>
                <div>
                  <p className="font-bold">{testimonial.name}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.pharmacy}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-primary text-primary-foreground py-20">
        <div className="max-w-4xl mx-auto px-4 md:px-8 text-center space-y-6">
          <h2 className="text-3xl md:text-4xl font-bold text-balance">Ready to Transform Your Pharmacy?</h2>
          <p className="text-lg text-primary-foreground/90 text-balance">
            Join 1000+ pharmacies already using MediFlux. Start free today, no credit card required.
          </p>
          <Button
            onClick={onGetStarted}
            size="lg"
            className="bg-primary-foreground text-primary hover:bg-primary-foreground/90"
          >
            Get Started Free
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12">
        <div className="max-w-6xl mx-auto px-4 md:px-8 text-center text-muted-foreground">
          <p>© 2025 MediFlux. All rights reserved.</p>
          <p className="text-sm mt-2">Built by CodeRoad Softwares</p>
        </div>
      </footer>
    </div>
  )
}
