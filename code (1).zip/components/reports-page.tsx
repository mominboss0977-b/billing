"use client"

import { Card } from "@/components/ui/card"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"

const monthlyData = [
  { month: "January", sales: 4000, expenses: 2400, profit: 1600 },
  { month: "February", sales: 3000, expenses: 1398, profit: 1602 },
  { month: "March", sales: 2000, expenses: 9800, profit: -7800 },
  { month: "April", sales: 2780, expenses: 3908, profit: -1128 },
  { month: "May", sales: 1890, expenses: 4800, profit: -2910 },
  { month: "June", sales: 2390, expenses: 3800, profit: -1410 },
]

const categoryData = [
  { category: "Pain Relief", sales: 4200 },
  { category: "Antibiotics", sales: 3800 },
  { category: "Vitamins", sales: 3200 },
  { category: "Digestive", sales: 2800 },
  { category: "Cough & Cold", sales: 2400 },
]

export default function ReportsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold mb-2">Reports & Analytics</h2>
        <p className="text-muted-foreground">View comprehensive insights about your pharmacy operations</p>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: "Monthly Revenue", value: "₹18,060", trend: "+12%" },
          { label: "Total Transactions", value: "1,245", trend: "+8%" },
          { label: "Average Bill Value", value: "₹1,450", trend: "+5%" },
          { label: "Profit Margin", value: "24.3%", trend: "+2.1%" },
        ].map((stat, idx) => (
          <Card key={idx} className="p-6">
            <p className="text-muted-foreground text-sm mb-2">{stat.label}</p>
            <div className="flex items-end justify-between">
              <h3 className="text-2xl font-bold">{stat.value}</h3>
              <span className="text-green-600 text-sm font-medium">{stat.trend}</span>
            </div>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="text-lg font-bold mb-4">Monthly Performance</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="sales" stroke="#1e7e8f" strokeWidth={2} />
              <Line type="monotone" dataKey="expenses" stroke="#dc2626" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-6">
          <h3 className="text-lg font-bold mb-4">Sales by Category</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={categoryData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="category" angle={-45} textAnchor="end" height={80} />
              <YAxis />
              <Tooltip />
              <Bar dataKey="sales" fill="#1e7e8f" />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Top Selling Medicines */}
      <Card className="p-6">
        <h3 className="text-lg font-bold mb-4">Top Selling Medicines</h3>
        <div className="space-y-3">
          {[
            { name: "Aspirin 500mg", units: 1240, revenue: "₹18,600" },
            { name: "Amoxicillin 250mg", units: 980, revenue: "₹44,100" },
            { name: "Paracetamol 650mg", units: 850, revenue: "₹10,200" },
            { name: "Cetirizine 10mg", units: 720, revenue: "₹15,840" },
            { name: "Ibuprofen 400mg", units: 650, revenue: "₹11,700" },
          ].map((med, idx) => (
            <div key={idx} className="flex items-center justify-between pb-3 border-b border-border last:border-0">
              <div>
                <p className="font-medium">{med.name}</p>
                <p className="text-sm text-muted-foreground">{med.units} units sold</p>
              </div>
              <p className="font-semibold">{med.revenue}</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}
