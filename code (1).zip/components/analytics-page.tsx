"use client"

import { Card } from "@/components/ui/card"
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"

const dailyData = [
  { date: "Mon", sales: 2400, customers: 240 },
  { date: "Tue", sales: 1398, customers: 221 },
  { date: "Wed", sales: 9800, customers: 229 },
  { date: "Thu", sales: 3908, customers: 200 },
  { date: "Fri", sales: 4800, customers: 218 },
  { date: "Sat", sales: 3800, customers: 250 },
  { date: "Sun", sales: 4300, customers: 210 },
]

const categoryData = [
  { category: "Pain Relief", sales: 4200, units: 520 },
  { category: "Antibiotics", sales: 3800, units: 380 },
  { category: "Vitamins", sales: 3200, units: 640 },
  { category: "Digestive", sales: 2800, units: 280 },
]

export default function AnalyticsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold mb-2">Advanced Analytics</h2>
        <p className="text-muted-foreground">Deep insights into your pharmacy performance</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: "Weekly Sales", value: "₹30,108", change: "+18%" },
          { label: "Avg Daily Sales", value: "₹4,301", change: "+12%" },
          { label: "Conversion Rate", value: "68%", change: "+5%" },
          { label: "Repeat Customers", value: "42%", change: "+8%" },
        ].map((metric, idx) => (
          <Card key={idx} className="p-6">
            <p className="text-muted-foreground text-sm mb-2">{metric.label}</p>
            <h3 className="text-2xl font-bold">{metric.value}</h3>
            <p className="text-sm text-green-600 mt-2">{metric.change}</p>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="text-lg font-bold mb-4">Daily Sales Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={dailyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Area type="monotone" dataKey="sales" fill="#1e7e8f" stroke="#1e7e8f" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-6">
          <h3 className="text-lg font-bold mb-4">Customer Activity</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={dailyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="customers" stroke="#3b9cb5" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Category Analysis */}
      <Card className="p-6">
        <h3 className="text-lg font-bold mb-4">Category Performance</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={categoryData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="category" />
            <YAxis yAxisId="left" />
            <YAxis yAxisId="right" orientation="right" />
            <Tooltip />
            <Legend />
            <Bar yAxisId="left" dataKey="sales" fill="#1e7e8f" name="Sales (₹)" />
            <Bar yAxisId="right" dataKey="units" fill="#3b9cb5" name="Units Sold" />
          </BarChart>
        </ResponsiveContainer>
      </Card>
    </div>
  )
}
