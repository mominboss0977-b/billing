"use client"

import { Card } from "@/components/ui/card"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

const salesData = [
  { month: "Jan", sales: 4000, revenue: 2400 },
  { month: "Feb", sales: 3000, revenue: 1398 },
  { month: "Mar", sales: 2000, revenue: 9800 },
  { month: "Apr", sales: 2780, revenue: 3908 },
  { month: "May", sales: 1890, revenue: 4800 },
  { month: "Jun", sales: 2390, revenue: 3800 },
]

const inventoryData = [
  { name: "In Stock", value: 65 },
  { name: "Low Stock", value: 20 },
  { name: "Out of Stock", value: 15 },
]

const COLORS = ["#1e7e8f", "#3b9cb5", "#6ab4c7"]

export default function Dashboard() {
  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: "Today's Sales", value: "₹12,450", change: "+12%" },
          { label: "Total Revenue", value: "₹2,45,680", change: "+8%" },
          { label: "Orders Today", value: "24", change: "+5%" },
          { label: "Active Medicines", value: "1,243", change: "+2%" },
        ].map((kpi, idx) => (
          <Card key={idx} className="p-6">
            <p className="text-muted-foreground text-sm mb-2">{kpi.label}</p>
            <div className="flex items-end justify-between">
              <h3 className="text-2xl font-bold">{kpi.value}</h3>
              <span className="text-green-600 text-sm font-medium">{kpi.change}</span>
            </div>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="text-lg font-bold mb-4">Sales Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={salesData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="revenue" stroke="#1e7e8f" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-6">
          <h3 className="text-lg font-bold mb-4">Inventory Status</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={inventoryData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {inventoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <Card className="p-6">
        <h3 className="text-lg font-bold mb-4">Sales by Category</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={salesData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="sales" fill="#1e7e8f" />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {/* Recent Activity */}
      <Card className="p-6">
        <h3 className="text-lg font-bold mb-4">Recent Transactions</h3>
        <div className="space-y-3">
          {[
            { id: "INV-001", amount: "₹2,450", status: "Completed", time: "2 mins ago" },
            { id: "INV-002", amount: "₹1,890", status: "Completed", time: "15 mins ago" },
            { id: "INV-003", amount: "₹3,200", status: "Pending", time: "1 hour ago" },
          ].map((tx) => (
            <div key={tx.id} className="flex items-center justify-between pb-3 border-b border-border last:border-0">
              <div>
                <p className="font-medium">{tx.id}</p>
                <p className="text-sm text-muted-foreground">{tx.time}</p>
              </div>
              <div className="text-right">
                <p className="font-semibold">{tx.amount}</p>
                <p className={`text-sm ${tx.status === "Completed" ? "text-green-600" : "text-yellow-600"}`}>
                  {tx.status}
                </p>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}
