"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { useState } from "react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

const expenseData = [
  { month: "Jan", rent: 15000, utilities: 5000, salaries: 40000 },
  { month: "Feb", rent: 15000, utilities: 4800, salaries: 40000 },
  { month: "Mar", rent: 15000, utilities: 5200, salaries: 40000 },
  { month: "Apr", rent: 15000, utilities: 4900, salaries: 40000 },
]

export default function ExpensesPage() {
  const [expenses] = useState([
    { id: 1, category: "Rent", amount: 15000, date: "2025-01-01", description: "Monthly rent" },
    { id: 2, category: "Utilities", amount: 5000, date: "2025-01-05", description: "Electricity & water" },
    { id: 3, category: "Salaries", amount: 40000, date: "2025-01-10", description: "Staff salaries" },
    { id: 4, category: "Supplies", amount: 8000, date: "2025-01-15", description: "Office supplies" },
  ])

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
        <div>
          <h2 className="text-3xl font-bold mb-2">Expense Management</h2>
          <p className="text-muted-foreground">Track and manage all pharmacy expenses</p>
        </div>
        <Button className="bg-primary hover:bg-primary text-primary-foreground gap-2">
          <Plus className="w-4 h-4" />
          Add Expense
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { label: "Monthly Expenses", value: "₹64,000", icon: "💰" },
          { label: "Budget Used", value: "85%", icon: "📊" },
          { label: "Remaining Budget", value: "₹12,000", icon: "✅" },
        ].map((stat, idx) => (
          <Card key={idx} className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm mb-2">{stat.label}</p>
                <h3 className="text-2xl font-bold">{stat.value}</h3>
              </div>
              <div className="text-3xl">{stat.icon}</div>
            </div>
          </Card>
        ))}
      </div>

      {/* Chart */}
      <Card className="p-6">
        <h3 className="text-lg font-bold mb-4">Monthly Expenses Trend</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={expenseData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="rent" fill="#1e7e8f" />
            <Bar dataKey="utilities" fill="#3b9cb5" />
            <Bar dataKey="salaries" fill="#6ab4c7" />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {/* Expenses List */}
      <Card className="p-6">
        <h3 className="text-lg font-bold mb-4">Recent Expenses</h3>
        <div className="space-y-3">
          {expenses.map((exp) => (
            <div key={exp.id} className="flex items-center justify-between pb-3 border-b border-border last:border-0">
              <div>
                <p className="font-medium">{exp.category}</p>
                <p className="text-sm text-muted-foreground">{exp.description}</p>
              </div>
              <div className="text-right">
                <p className="font-bold">₹{exp.amount.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">{exp.date}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}
