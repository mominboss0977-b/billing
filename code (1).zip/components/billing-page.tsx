"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Plus, Search } from "lucide-react"
import { useState } from "react"

export default function BillingPage() {
  const [bills, setBills] = useState([
    {
      id: "INV-001",
      customerName: "Ram Kumar",
      date: "2025-01-15",
      amount: 2450,
      status: "Paid",
      items: 5,
    },
    {
      id: "INV-002",
      customerName: "Priya Singh",
      date: "2025-01-15",
      amount: 1890,
      status: "Paid",
      items: 3,
    },
    {
      id: "INV-003",
      customerName: "Ahmed Hassan",
      date: "2025-01-15",
      amount: 3200,
      status: "Pending",
      items: 8,
    },
    {
      id: "INV-004",
      customerName: "Divya Patel",
      date: "2025-01-14",
      amount: 1560,
      status: "Paid",
      items: 4,
    },
  ])

  const [search, setSearch] = useState("")

  const filteredBills = bills.filter(
    (bill) =>
      bill.id.toLowerCase().includes(search.toLowerCase()) ||
      bill.customerName.toLowerCase().includes(search.toLowerCase()),
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
        <div>
          <h2 className="text-3xl font-bold mb-2">Billing Management</h2>
          <p className="text-muted-foreground">Create and manage GST-compliant bills</p>
        </div>
        <Button className="bg-primary hover:bg-primary text-primary-foreground gap-2">
          <Plus className="w-4 h-4" />
          Create New Bill
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { label: "Total Bills", value: "847", change: "+12 today" },
          { label: "Total Revenue", value: "₹2,45,680", change: "+₹45,230 today" },
          { label: "Pending Amount", value: "₹34,560", change: "From 5 invoices" },
        ].map((stat, idx) => (
          <Card key={idx} className="p-6">
            <p className="text-muted-foreground text-sm mb-2">{stat.label}</p>
            <h3 className="text-2xl font-bold mb-1">{stat.value}</h3>
            <p className="text-sm text-muted-foreground">{stat.change}</p>
          </Card>
        ))}
      </div>

      {/* Search and Filter */}
      <Card className="p-6">
        <div className="flex flex-col gap-4 mb-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by invoice ID or customer name..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Bills Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Invoice ID</th>
                <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Customer</th>
                <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Date</th>
                <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Items</th>
                <th className="text-right py-3 px-4 font-semibold text-muted-foreground">Amount</th>
                <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredBills.map((bill) => (
                <tr key={bill.id} className="border-b border-border hover:bg-muted/50 transition-colors">
                  <td className="py-4 px-4 font-medium">{bill.id}</td>
                  <td className="py-4 px-4">{bill.customerName}</td>
                  <td className="py-4 px-4 text-sm text-muted-foreground">{bill.date}</td>
                  <td className="py-4 px-4 text-sm">{bill.items} items</td>
                  <td className="py-4 px-4 text-right font-semibold">₹{bill.amount.toLocaleString()}</td>
                  <td className="py-4 px-4">
                    <span
                      className={`text-xs px-3 py-1 rounded-full font-medium ${
                        bill.status === "Paid" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"
                      }`}
                    >
                      {bill.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
