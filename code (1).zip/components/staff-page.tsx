"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { useState } from "react"

export default function StaffPage() {
  const [staff] = useState([
    {
      id: 1,
      name: "Rajesh Kumar",
      role: "Pharmacist",
      email: "rajesh@pharmacy.com",
      phone: "9876543210",
      joinDate: "2024-01-15",
      status: "Active",
    },
    {
      id: 2,
      name: "Priya Singh",
      role: "Counter Staff",
      email: "priya@pharmacy.com",
      phone: "9876543211",
      joinDate: "2024-03-20",
      status: "Active",
    },
    {
      id: 3,
      name: "Arun Patel",
      role: "Delivery Executive",
      email: "arun@pharmacy.com",
      phone: "9876543212",
      joinDate: "2024-06-10",
      status: "Active",
    },
  ])

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
        <div>
          <h2 className="text-3xl font-bold mb-2">Staff Management</h2>
          <p className="text-muted-foreground">Manage your team and permissions</p>
        </div>
        <Button className="bg-primary hover:bg-primary text-primary-foreground gap-2">
          <Plus className="w-4 h-4" />
          Add Staff
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { label: "Total Staff", value: "3", icon: "👥" },
          { label: "Active Users", value: "3", icon: "✅" },
          { label: "Roles", value: "3 Types", icon: "🔑" },
        ].map((stat, idx) => (
          <Card key={idx} className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">{stat.label}</p>
                <p className="text-2xl font-bold mt-2">{stat.value}</p>
              </div>
              <div className="text-3xl">{stat.icon}</div>
            </div>
          </Card>
        ))}
      </div>

      {/* Staff Table */}
      <Card className="p-6">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Name</th>
                <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Role</th>
                <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Email</th>
                <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Phone</th>
                <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Join Date</th>
                <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Status</th>
              </tr>
            </thead>
            <tbody>
              {staff.map((member) => (
                <tr key={member.id} className="border-b border-border hover:bg-muted/50">
                  <td className="py-4 px-4 font-medium">{member.name}</td>
                  <td className="py-4 px-4">{member.role}</td>
                  <td className="py-4 px-4 text-sm">{member.email}</td>
                  <td className="py-4 px-4 text-sm">{member.phone}</td>
                  <td className="py-4 px-4 text-sm text-muted-foreground">{member.joinDate}</td>
                  <td className="py-4 px-4">
                    <span className="text-xs px-3 py-1 rounded-full font-medium bg-green-100 text-green-700">
                      {member.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
