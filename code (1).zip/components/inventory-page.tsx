"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Plus, AlertTriangle, TrendingDown } from "lucide-react"
import { useState } from "react"

export default function InventoryPage() {
  const [medicines] = useState([
    {
      id: 1,
      name: "Aspirin 500mg",
      batchNo: "BT-2024-001",
      quantity: 450,
      expiry: "2026-12-31",
      price: 15,
      status: "In Stock",
    },
    {
      id: 2,
      name: "Amoxicillin 250mg",
      batchNo: "BT-2024-002",
      quantity: 23,
      expiry: "2025-06-30",
      price: 45,
      status: "Low Stock",
    },
    {
      id: 3,
      name: "Paracetamol 650mg",
      batchNo: "BT-2024-003",
      quantity: 0,
      expiry: "2025-03-15",
      price: 12,
      status: "Out of Stock",
    },
    {
      id: 4,
      name: "Cetirizine 10mg",
      batchNo: "BT-2024-004",
      quantity: 320,
      expiry: "2026-09-30",
      price: 22,
      status: "In Stock",
    },
    {
      id: 5,
      name: "Ibuprofen 400mg",
      batchNo: "BT-2024-005",
      quantity: 15,
      expiry: "2025-04-30",
      price: 18,
      status: "Low Stock",
    },
  ])

  const [search, setSearch] = useState("")

  const filteredMedicines = medicines.filter(
    (med) =>
      med.name.toLowerCase().includes(search.toLowerCase()) || med.batchNo.toLowerCase().includes(search.toLowerCase()),
  )

  const lowStockCount = medicines.filter((m) => m.quantity < 50).length
  const expiringCount = medicines.filter((m) => {
    const expiry = new Date(m.expiry)
    const days = (expiry.getTime() - Date.now()) / (1000 * 60 * 60 * 24)
    return days < 90
  }).length

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
        <div>
          <h2 className="text-3xl font-bold mb-2">Inventory Management</h2>
          <p className="text-muted-foreground">Track and manage your pharmacy stock</p>
        </div>
        <Button className="bg-primary hover:bg-primary text-primary-foreground gap-2">
          <Plus className="w-4 h-4" />
          Add Medicine
        </Button>
      </div>

      {/* Alerts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {[
          {
            icon: <TrendingDown className="w-5 h-5" />,
            label: "Low Stock Items",
            value: lowStockCount,
            color: "text-yellow-600 bg-yellow-50",
          },
          {
            icon: <AlertTriangle className="w-5 h-5" />,
            label: "Expiring Soon",
            value: expiringCount,
            color: "text-red-600 bg-red-50",
          },
        ].map((alert, idx) => (
          <Card key={idx} className={`p-6 ${alert.color}`}>
            <div className="flex items-center gap-4">
              <div className={alert.color}>{alert.icon}</div>
              <div>
                <p className="text-sm font-medium">{alert.label}</p>
                <p className="text-2xl font-bold">{alert.value} items</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Search */}
      <Card className="p-6">
        <Input
          placeholder="Search by medicine name or batch number..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="mb-6"
        />

        {/* Medicines Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Medicine Name</th>
                <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Batch No</th>
                <th className="text-right py-3 px-4 font-semibold text-muted-foreground">Quantity</th>
                <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Expiry</th>
                <th className="text-right py-3 px-4 font-semibold text-muted-foreground">Price</th>
                <th className="text-left py-3 px-4 font-semibold text-muted-foreground">Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredMedicines.map((med) => (
                <tr key={med.id} className="border-b border-border hover:bg-muted/50 transition-colors">
                  <td className="py-4 px-4 font-medium">{med.name}</td>
                  <td className="py-4 px-4 text-sm text-muted-foreground">{med.batchNo}</td>
                  <td className="py-4 px-4 text-right font-semibold">{med.quantity}</td>
                  <td className="py-4 px-4 text-sm">{med.expiry}</td>
                  <td className="py-4 px-4 text-right">₹{med.price}</td>
                  <td className="py-4 px-4">
                    <span
                      className={`text-xs px-3 py-1 rounded-full font-medium ${
                        med.status === "In Stock"
                          ? "bg-green-100 text-green-700"
                          : med.status === "Low Stock"
                            ? "bg-yellow-100 text-yellow-700"
                            : "bg-red-100 text-red-700"
                      }`}
                    >
                      {med.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
